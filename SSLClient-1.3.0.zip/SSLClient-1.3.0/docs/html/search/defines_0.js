var searchData=
[
  ['_5f_5ftime_5fdays_5f_5f',['__TIME_DAYS__',['../time__macros_8h.html#a7f2cdee2eebbccd45c179a50a0bbabcf',1,'time_macros.h']]],
  ['_5f_5ftime_5fhours_5f_5f',['__TIME_HOURS__',['../time__macros_8h.html#a2488d1ddab7e5fa119da3421462231c4',1,'time_macros.h']]],
  ['_5f_5ftime_5fminutes_5f_5f',['__TIME_MINUTES__',['../time__macros_8h.html#ab3592442029a102b388fafeadc4a6ab8',1,'time_macros.h']]],
  ['_5f_5ftime_5fmonth_5f_5f',['__TIME_MONTH__',['../time__macros_8h.html#ac8f6b75d9e04634818984ba400d0dee1',1,'time_macros.h']]],
  ['_5f_5ftime_5fseconds_5f_5f',['__TIME_SECONDS__',['../time__macros_8h.html#a38ac93dd8bfe385ff915a82c92bbfc97',1,'time_macros.h']]],
  ['_5f_5ftime_5fyears_5f_5f',['__TIME_YEARS__',['../time__macros_8h.html#a56482fcc86a55713dee595c2092ed376',1,'time_macros.h']]],
  ['_5funix_5ftimestamp',['_UNIX_TIMESTAMP',['../time__macros_8h.html#a868143e0521daf07b25a2f3947cf54a3',1,'time_macros.h']]],
  ['_5funix_5ftimestamp_5ffday',['_UNIX_TIMESTAMP_FDAY',['../time__macros_8h.html#ab6c76862964ff7e543fd9d5807b2fa79',1,'time_macros.h']]],
  ['_5funix_5ftimestamp_5fyday',['_UNIX_TIMESTAMP_YDAY',['../time__macros_8h.html#a5ab60a7e3e1b6e0a919b3a37bc0d4b97',1,'time_macros.h']]]
];
